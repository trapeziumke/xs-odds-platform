
# XS Odds Deployment Guide

## Frontend
Deploy frontend folder to Vercel.

## Backend
Deploy backend to Render, Railway or VPS.

## Environment Variables
- MONGO_URI
- JWT_SECRET
- TELEGRAM_BOT_TOKEN
- ODDS_API_KEY

## Telegram Automation
Use BotFather to create Telegram bot.
